# Othello-Monte-Carlo

This program uses the monte-carlo algorithm to win Othello

The assignment can be run using the provided make file

## Give-away-minimax

Using the give away heurisitic, the chances of winning are considerably
higher for the AI. The giveaway heuristic lets the opponent take
the first 40 moves, and then the minimax kicks in. Though uninuitive, this
allows the AI to take the bulk of all pieces leading to a win most times




